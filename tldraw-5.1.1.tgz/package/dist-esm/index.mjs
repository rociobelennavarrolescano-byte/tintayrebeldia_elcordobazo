import { registerTldrawLibraryVersion } from "@tldraw/editor";
import { getPointsFromDrawSegment, getPointsFromDrawSegments } from "./lib/shapes/draw/getPath.mjs";
import {
  PathBuilder,
  PathBuilderGeometry2d
} from "./lib/shapes/shared/PathBuilder.mjs";
import { usePrefersReducedMotion } from "./lib/shapes/shared/usePrefersReducedMotion.mjs";
import { startEditingShapeWithRichText } from "./lib/tools/SelectTool/selectHelpers.mjs";
import { DefaultA11yAnnouncer, useSelectedShapesAnnouncer } from "./lib/ui/components/A11y.mjs";
import { AccessibilityMenu } from "./lib/ui/components/AccessibilityMenu.mjs";
import { ColorSchemeMenu } from "./lib/ui/components/ColorSchemeMenu.mjs";
import { DefaultFollowingIndicator } from "./lib/ui/components/DefaultFollowingIndicator.mjs";
import { DefaultDialogs } from "./lib/ui/components/Dialogs.mjs";
import {
  TldrawUiColumn,
  TldrawUiGrid,
  TldrawUiOrientationProvider,
  TldrawUiRow,
  useTldrawUiOrientation
} from "./lib/ui/components/primitives/layout.mjs";
import {
  TldrawUiMenuActionCheckboxItem
} from "./lib/ui/components/primitives/menus/TldrawUiMenuActionCheckboxItem.mjs";
import {
  TldrawUiMenuActionItem
} from "./lib/ui/components/primitives/menus/TldrawUiMenuActionItem.mjs";
import {
  TldrawUiMenuToolItem
} from "./lib/ui/components/primitives/menus/TldrawUiMenuToolItem.mjs";
import { DefaultToasts } from "./lib/ui/components/Toasts.mjs";
import { TldrawUiTranslationProvider } from "./lib/ui/hooks/useTranslation/useTranslation.mjs";
export * from "@tldraw/editor";
import { BookmarkAssetUtil } from "./lib/assets/BookmarkAssetUtil.mjs";
import { ImageAssetUtil } from "./lib/assets/ImageAssetUtil.mjs";
import { VideoAssetUtil } from "./lib/assets/VideoAssetUtil.mjs";
import {
  ArrowBindingHintOverlayUtil
} from "./lib/overlays/ArrowBindingHintOverlayUtil.mjs";
import { ArrowBindingUtil } from "./lib/bindings/arrow/ArrowBindingUtil.mjs";
import { ArrowHintOverlayUtil } from "./lib/overlays/ArrowHintOverlayUtil.mjs";
import {
  BrushOverlayUtil
} from "./lib/overlays/BrushOverlayUtil.mjs";
import { ZoomBrushOverlayUtil } from "./lib/overlays/ZoomBrushOverlayUtil.mjs";
import { ScribbleOverlayUtil } from "./lib/overlays/ScribbleOverlayUtil.mjs";
import {
  CollaboratorBrushOverlayUtil
} from "./lib/overlays/CollaboratorBrushOverlayUtil.mjs";
import {
  CollaboratorScribbleOverlayUtil
} from "./lib/overlays/CollaboratorScribbleOverlayUtil.mjs";
import {
  CollaboratorHintOverlayUtil
} from "./lib/overlays/CollaboratorHintOverlayUtil.mjs";
import {
  CollaboratorCursorOverlayUtil
} from "./lib/overlays/CollaboratorCursorOverlayUtil.mjs";
import {
  CollaboratorShapeIndicatorOverlayUtil
} from "./lib/overlays/CollaboratorShapeIndicatorOverlayUtil.mjs";
import {
  ShapeHandleOverlayUtil
} from "./lib/overlays/ShapeHandleOverlayUtil.mjs";
import {
  SelectionForegroundOverlayUtil
} from "./lib/overlays/SelectionForegroundOverlayUtil.mjs";
import {
  SnapIndicatorOverlayUtil
} from "./lib/overlays/SnapIndicatorOverlayUtil.mjs";
import { defaultAssetUtils } from "./lib/defaultAssetUtils.mjs";
import { defaultBindingUtils } from "./lib/defaultBindingUtils.mjs";
import { defaultOverlayUtils } from "./lib/defaultOverlayUtils.mjs";
import {
  DEFAULT_EMBED_DEFINITIONS,
  embedShapePermissionDefaults,
  unknownEmbedShapePermissionOverrides
} from "./lib/defaultEmbedDefinitions.mjs";
import {
  centerSelectionAroundPoint,
  createEmptyBookmarkShape,
  createShapesForAssets,
  DEFAULT_MAX_ASSET_SIZE,
  DEFAULT_MAX_IMAGE_DIMENSION,
  defaultHandleExternalEmbedContent,
  defaultHandleExternalExcalidrawContent,
  defaultHandleExternalFileAsset,
  defaultHandleExternalFileContent,
  defaultHandleExternalFileReplaceContent,
  defaultHandleExternalSvgTextContent,
  defaultHandleExternalTextContent,
  defaultHandleExternalTldrawContent,
  defaultHandleExternalUrlAsset,
  defaultHandleExternalUrlContent,
  getAssetInfo,
  notifyIfFileNotAllowed,
  registerDefaultExternalContentHandlers
} from "./lib/defaultExternalContentHandlers.mjs";
import { defaultShapeTools } from "./lib/defaultShapeTools.mjs";
import { defaultShapeUtils } from "./lib/defaultShapeUtils.mjs";
import { registerDefaultSideEffects } from "./lib/defaultSideEffects.mjs";
import { defaultTools } from "./lib/defaultTools.mjs";
import { ArrowShapeTool } from "./lib/shapes/arrow/ArrowShapeTool.mjs";
import { ArrowShapeUtil } from "./lib/shapes/arrow/ArrowShapeUtil.mjs";
import {
  clearArrowTargetState,
  getArrowTargetState,
  updateArrowTargetState
} from "./lib/shapes/arrow/arrowTargetState.mjs";
import { getArrowInfo } from "./lib/shapes/arrow/getArrowInfo.mjs";
import {
  getArrowBindings,
  getArrowTerminalsInArrowSpace
} from "./lib/shapes/arrow/shared.mjs";
import { createBookmarkFromUrl } from "./lib/shapes/bookmark/bookmarks.mjs";
import {
  BookmarkShapeUtil
} from "./lib/shapes/bookmark/BookmarkShapeUtil.mjs";
import { DrawShapeTool } from "./lib/shapes/draw/DrawShapeTool.mjs";
import {
  DrawShapeUtil
} from "./lib/shapes/draw/DrawShapeUtil.mjs";
import {
  EmbedShapeUtil
} from "./lib/shapes/embed/EmbedShapeUtil.mjs";
import { FrameShapeTool } from "./lib/shapes/frame/FrameShapeTool.mjs";
import {
  FrameShapeUtil
} from "./lib/shapes/frame/FrameShapeUtil.mjs";
import { GeoShapeTool } from "./lib/shapes/geo/GeoShapeTool.mjs";
import {
  GeoShapeUtil
} from "./lib/shapes/geo/GeoShapeUtil.mjs";
import {
  defaultGeoTypeDefinitions,
  getGeoTypeDefinition
} from "./lib/shapes/geo/getGeoShapePath.mjs";
import { HighlightShapeTool } from "./lib/shapes/highlight/HighlightShapeTool.mjs";
import {
  HighlightShapeUtil
} from "./lib/shapes/highlight/HighlightShapeUtil.mjs";
import {
  ImageShapeUtil
} from "./lib/shapes/image/ImageShapeUtil.mjs";
import { LineShapeTool } from "./lib/shapes/line/LineShapeTool.mjs";
import {
  LineShapeUtil
} from "./lib/shapes/line/LineShapeUtil.mjs";
import { NoteShapeTool } from "./lib/shapes/note/NoteShapeTool.mjs";
import {
  NoteShapeUtil
} from "./lib/shapes/note/NoteShapeUtil.mjs";
import {
  ASPECT_RATIO_OPTIONS,
  ASPECT_RATIO_TO_VALUE,
  getCropBox,
  getDefaultCrop,
  getUncroppedSize
} from "./lib/shapes/shared/crop.mjs";
import { getFontFamily } from "./lib/shapes/shared/default-shape-constants.mjs";
import {
  allDefaultFontFaces,
  DefaultFontFaces
} from "./lib/shapes/shared/defaultFonts.mjs";
import { getStroke } from "./lib/shapes/shared/freehand/getStroke.mjs";
import { getStrokeOutlinePoints } from "./lib/shapes/shared/freehand/getStrokeOutlinePoints.mjs";
import { getStrokePoints } from "./lib/shapes/shared/freehand/getStrokePoints.mjs";
import { setStrokePointRadii } from "./lib/shapes/shared/freehand/setStrokePointRadii.mjs";
import { getSvgPathFromStrokePoints } from "./lib/shapes/shared/freehand/svg.mjs";
import {
  getDisplayValues
} from "./lib/shapes/shared/getDisplayValues.mjs";
import { PlainTextLabel } from "./lib/shapes/shared/PlainTextLabel.mjs";
import {
  RichTextLabel,
  RichTextSVG
} from "./lib/shapes/shared/RichTextLabel.mjs";
import { useEditablePlainText } from "./lib/shapes/shared/useEditablePlainText.mjs";
import { useEditableRichText } from "./lib/shapes/shared/useEditableRichText.mjs";
import {
  useImageOrVideoAsset
} from "./lib/shapes/shared/useImageOrVideoAsset.mjs";
import { PlainTextArea } from "./lib/shapes/text/PlainTextArea.mjs";
import { RichTextArea } from "./lib/shapes/text/RichTextArea.mjs";
import { TextShapeTool } from "./lib/shapes/text/TextShapeTool.mjs";
import {
  TextShapeUtil
} from "./lib/shapes/text/TextShapeUtil.mjs";
import {
  VideoShapeUtil
} from "./lib/shapes/video/VideoShapeUtil.mjs";
import { getColorStyleItems, getFontStyleItems } from "./lib/styles.mjs";
import { Tldraw } from "./lib/Tldraw.mjs";
import { TldrawImage } from "./lib/TldrawImage.mjs";
import { EraserTool } from "./lib/tools/EraserTool/EraserTool.mjs";
import { HandTool } from "./lib/tools/HandTool/HandTool.mjs";
import { LaserTool } from "./lib/tools/LaserTool/LaserTool.mjs";
import { getHitShapeOnCanvasPointerDown } from "./lib/tools/selection-logic/getHitShapeOnCanvasPointerDown.mjs";
import { SelectTool } from "./lib/tools/SelectTool/SelectTool.mjs";
import { ZoomTool } from "./lib/tools/ZoomTool/ZoomTool.mjs";
import {
  setDefaultUiAssetUrls
} from "./lib/ui/assetUrls.mjs";
import {
  DefaultActionsMenu
} from "./lib/ui/components/ActionsMenu/DefaultActionsMenu.mjs";
import {
  AlignMenuItems,
  DefaultActionsMenuContent,
  DistributeMenuItems,
  GroupOrUngroupMenuItem,
  ReorderMenuItems,
  RotateCWMenuItem,
  StackMenuItems,
  ZoomOrRotateMenuItem
} from "./lib/ui/components/ActionsMenu/DefaultActionsMenuContent.mjs";
import {
  DefaultContextMenu,
  DefaultContextMenu as DefaultContextMenu2
} from "./lib/ui/components/ContextMenu/DefaultContextMenu.mjs";
import { DefaultContextMenuContent } from "./lib/ui/components/ContextMenu/DefaultContextMenuContent.mjs";
import {
  DefaultDebugMenu
} from "./lib/ui/components/DebugMenu/DefaultDebugMenu.mjs";
import {
  DebugFlags,
  DefaultDebugMenuContent,
  ExampleDialog,
  FeatureFlags
} from "./lib/ui/components/DebugMenu/DefaultDebugMenuContent.mjs";
import { DefaultMenuPanel } from "./lib/ui/components/DefaultMenuPanel.mjs";
import {
  DefaultHelperButtons
} from "./lib/ui/components/HelperButtons/DefaultHelperButtons.mjs";
import { DefaultHelperButtonsContent } from "./lib/ui/components/HelperButtons/DefaultHelperButtonsContent.mjs";
import {
  DefaultHelpMenu
} from "./lib/ui/components/HelpMenu/DefaultHelpMenu.mjs";
import {
  DefaultHelpMenuContent,
  KeyboardShortcutsMenuItem
} from "./lib/ui/components/HelpMenu/DefaultHelpMenuContent.mjs";
import {
  DefaultKeyboardShortcutsDialog
} from "./lib/ui/components/KeyboardShortcutsDialog/DefaultKeyboardShortcutsDialog.mjs";
import { DefaultKeyboardShortcutsDialogContent } from "./lib/ui/components/KeyboardShortcutsDialog/DefaultKeyboardShortcutsDialogContent.mjs";
import { LanguageMenu } from "./lib/ui/components/LanguageMenu.mjs";
import { InputModeMenu } from "./lib/ui/components/InputModeMenu.mjs";
import {
  DefaultMainMenu
} from "./lib/ui/components/MainMenu/DefaultMainMenu.mjs";
import {
  DefaultMainMenuContent,
  EditSubmenu,
  ExportFileContentSubMenu,
  ExtrasGroup,
  LockGroup,
  MiscMenuGroup,
  PreferencesGroup,
  UndoRedoGroup,
  ViewSubmenu
} from "./lib/ui/components/MainMenu/DefaultMainMenuContent.mjs";
import {
  ArrangeMenuSubmenu,
  ClipboardMenuGroup,
  ConversionsMenuGroup,
  ConvertToBookmarkMenuItem,
  ConvertToEmbedMenuItem,
  CopyAsMenuGroup,
  CopyMenuItem,
  CursorChatItem,
  CutMenuItem,
  DeleteMenuItem,
  DuplicateMenuItem,
  EditLinkMenuItem,
  EditMenuSubmenu,
  FitFrameToContentMenuItem,
  GroupMenuItem,
  MoveToPageMenu,
  PasteMenuItem,
  PrintItem,
  RemoveFrameMenuItem,
  ReorderMenuSubmenu,
  SelectAllMenuItem,
  ToggleAutoSizeMenuItem,
  ToggleDebugModeItem,
  ToggleDynamicSizeModeItem,
  ToggleEdgeScrollingItem,
  ToggleEnhancedA11yModeItem,
  ToggleFocusModeItem,
  ToggleGridItem,
  ToggleInvertZoomItem,
  ToggleKeyboardShortcutsItem,
  ToggleLockMenuItem,
  TogglePasteAtCursorItem,
  ToggleReduceMotionItem,
  ToggleSnapModeItem,
  ToggleToolLockItem,
  ToggleTransparentBgMenuItem,
  ToggleWrapModeItem,
  UngroupMenuItem,
  UnlockAllMenuItem,
  ZoomTo100MenuItem,
  ZoomToFitMenuItem,
  ZoomToSelectionMenuItem
} from "./lib/ui/components/menu-items.mjs";
import { DefaultMinimap } from "./lib/ui/components/Minimap/DefaultMinimap.mjs";
import { MobileStylePanel } from "./lib/ui/components/MobileStylePanel.mjs";
import { DefaultNavigationPanel } from "./lib/ui/components/NavigationPanel/DefaultNavigationPanel.mjs";
import { OfflineIndicator } from "./lib/ui/components/OfflineIndicator/OfflineIndicator.mjs";
import { DefaultPageMenu } from "./lib/ui/components/PageMenu/DefaultPageMenu.mjs";
import { PageItemInput } from "./lib/ui/components/PageMenu/PageItemInput.mjs";
import {
  PageItemSubmenu
} from "./lib/ui/components/PageMenu/PageItemSubmenu.mjs";
import {
  TldrawUiButton
} from "./lib/ui/components/primitives/Button/TldrawUiButton.mjs";
import {
  TldrawUiButtonCheck
} from "./lib/ui/components/primitives/Button/TldrawUiButtonCheck.mjs";
import {
  TldrawUiButtonIcon
} from "./lib/ui/components/primitives/Button/TldrawUiButtonIcon.mjs";
import {
  TldrawUiButtonLabel
} from "./lib/ui/components/primitives/Button/TldrawUiButtonLabel.mjs";
import {
  TldrawUiMenuCheckboxItem
} from "./lib/ui/components/primitives/menus/TldrawUiMenuCheckboxItem.mjs";
import {
  TldrawUiMenuContextProvider
} from "./lib/ui/components/primitives/menus/TldrawUiMenuContext.mjs";
import {
  TldrawUiMenuGroup
} from "./lib/ui/components/primitives/menus/TldrawUiMenuGroup.mjs";
import {
  TldrawUiMenuItem
} from "./lib/ui/components/primitives/menus/TldrawUiMenuItem.mjs";
import {
  TldrawUiMenuSubmenu
} from "./lib/ui/components/primitives/menus/TldrawUiMenuSubmenu.mjs";
import {
  TldrawUiContextualToolbar
} from "./lib/ui/components/primitives/TldrawUiContextualToolbar.mjs";
import {
  TldrawUiDialogBody,
  TldrawUiDialogCloseButton,
  TldrawUiDialogFooter,
  TldrawUiDialogHeader,
  TldrawUiDialogTitle
} from "./lib/ui/components/primitives/TldrawUiDialog.mjs";
import {
  TldrawUiDropdownMenuCheckboxItem,
  TldrawUiDropdownMenuContent,
  TldrawUiDropdownMenuGroup,
  TldrawUiDropdownMenuIndicator,
  TldrawUiDropdownMenuItem,
  TldrawUiDropdownMenuRoot,
  TldrawUiDropdownMenuSub,
  TldrawUiDropdownMenuSubContent,
  TldrawUiDropdownMenuSubTrigger,
  TldrawUiDropdownMenuTrigger
} from "./lib/ui/components/primitives/TldrawUiDropdownMenu.mjs";
import {
  TldrawUiIcon
} from "./lib/ui/components/primitives/TldrawUiIcon.mjs";
import { TldrawUiInput } from "./lib/ui/components/primitives/TldrawUiInput.mjs";
import { TldrawUiKbd } from "./lib/ui/components/primitives/TldrawUiKbd.mjs";
import {
  TldrawUiPopover,
  TldrawUiPopoverContent,
  TldrawUiPopoverTrigger
} from "./lib/ui/components/primitives/TldrawUiPopover.mjs";
import {
  TldrawUiSelect,
  TldrawUiSelectContent,
  TldrawUiSelectItem,
  TldrawUiSelectTrigger,
  TldrawUiSelectValue
} from "./lib/ui/components/primitives/TldrawUiSelect.mjs";
import { TldrawUiSlider } from "./lib/ui/components/primitives/TldrawUiSlider.mjs";
import {
  TldrawUiToolbar,
  TldrawUiToolbarButton,
  TldrawUiToolbarToggleGroup,
  TldrawUiToolbarToggleItem
} from "./lib/ui/components/primitives/TldrawUiToolbar.mjs";
import {
  hideAllTooltips,
  TldrawUiTooltip,
  TldrawUiTooltipProvider
} from "./lib/ui/components/primitives/TldrawUiTooltip.mjs";
import {
  DefaultQuickActions
} from "./lib/ui/components/QuickActions/DefaultQuickActions.mjs";
import { DefaultQuickActionsContent } from "./lib/ui/components/QuickActions/DefaultQuickActionsContent.mjs";
import {
  DefaultPeopleMenu,
  DefaultPeopleMenu as DefaultPeopleMenu2
} from "./lib/ui/components/SharePanel/DefaultPeopleMenu.mjs";
import {
  DefaultPeopleMenuAvatar
} from "./lib/ui/components/SharePanel/DefaultPeopleMenuAvatar.mjs";
import {
  DefaultPeopleMenuContent
} from "./lib/ui/components/SharePanel/DefaultPeopleMenuContent.mjs";
import {
  DefaultPeopleMenuFacePile
} from "./lib/ui/components/SharePanel/DefaultPeopleMenuFacePile.mjs";
import {
  DefaultPeopleMenuItem
} from "./lib/ui/components/SharePanel/DefaultPeopleMenuItem.mjs";
import { DefaultSharePanel } from "./lib/ui/components/SharePanel/DefaultSharePanel.mjs";
import { DefaultUserPresenceEditor } from "./lib/ui/components/SharePanel/DefaultUserPresenceEditor.mjs";
import { Spinner } from "./lib/ui/components/Spinner.mjs";
import {
  DefaultStylePanel
} from "./lib/ui/components/StylePanel/DefaultStylePanel.mjs";
import {
  DefaultStylePanelContent,
  StylePanelArrowheadPicker,
  StylePanelArrowKindPicker,
  StylePanelColorPicker,
  StylePanelDashPicker,
  StylePanelFillPicker,
  StylePanelFontPicker,
  StylePanelGeoShapePicker,
  StylePanelLabelAlignPicker,
  StylePanelOpacityPicker,
  StylePanelSection,
  StylePanelSizePicker,
  StylePanelSplinePicker,
  StylePanelTextAlignPicker
} from "./lib/ui/components/StylePanel/DefaultStylePanelContent.mjs";
import {
  StylePanelButtonPicker,
  StylePanelButtonPickerInline
} from "./lib/ui/components/StylePanel/StylePanelButtonPicker.mjs";
import {
  StylePanelContextProvider,
  useStylePanelContext
} from "./lib/ui/components/StylePanel/StylePanelContext.mjs";
import {
  StylePanelDoubleDropdownPicker,
  StylePanelDoubleDropdownPickerInline
} from "./lib/ui/components/StylePanel/StylePanelDoubleDropdownPicker.mjs";
import {
  StylePanelDropdownPicker,
  StylePanelDropdownPickerInline
} from "./lib/ui/components/StylePanel/StylePanelDropdownPicker.mjs";
import {
  StylePanelSubheading
} from "./lib/ui/components/StylePanel/StylePanelSubheading.mjs";
import {
  DefaultImageToolbar
} from "./lib/ui/components/Toolbar/DefaultImageToolbar.mjs";
import {
  DefaultImageToolbarContent
} from "./lib/ui/components/Toolbar/DefaultImageToolbarContent.mjs";
import {
  DefaultRichTextToolbar
} from "./lib/ui/components/Toolbar/DefaultRichTextToolbar.mjs";
import {
  DefaultRichTextToolbarContent
} from "./lib/ui/components/Toolbar/DefaultRichTextToolbarContent.mjs";
import {
  DefaultToolbar
} from "./lib/ui/components/Toolbar/DefaultToolbar.mjs";
import {
  ArrowDownToolbarItem,
  ArrowLeftToolbarItem,
  ArrowRightToolbarItem,
  ArrowToolbarItem,
  ArrowUpToolbarItem,
  AssetToolbarItem,
  CheckBoxToolbarItem,
  CloudToolbarItem,
  DefaultToolbarContent,
  DiamondToolbarItem,
  DrawToolbarItem,
  EllipseToolbarItem,
  EraserToolbarItem,
  FrameToolbarItem,
  HandToolbarItem,
  HeartToolbarItem,
  HexagonToolbarItem,
  HighlightToolbarItem,
  LaserToolbarItem,
  LineToolbarItem,
  NoteToolbarItem,
  OvalToolbarItem,
  RectangleToolbarItem,
  RhombusToolbarItem,
  SelectToolbarItem,
  StarToolbarItem,
  TextToolbarItem,
  ToolbarItem,
  TrapezoidToolbarItem,
  TriangleToolbarItem,
  useIsToolSelected,
  XBoxToolbarItem
} from "./lib/ui/components/Toolbar/DefaultToolbarContent.mjs";
import {
  DefaultVideoToolbar
} from "./lib/ui/components/Toolbar/DefaultVideoToolbar.mjs";
import {
  DefaultVideoToolbarContent
} from "./lib/ui/components/Toolbar/DefaultVideoToolbarContent.mjs";
import {
  OverflowingToolbar
} from "./lib/ui/components/Toolbar/OverflowingToolbar.mjs";
import {
  ToggleToolLockedButton
} from "./lib/ui/components/Toolbar/ToggleToolLockedButton.mjs";
import {
  CenteredTopPanelContainer
} from "./lib/ui/components/TopPanel/CenteredTopPanelContainer.mjs";
import {
  DefaultZoomMenu
} from "./lib/ui/components/ZoomMenu/DefaultZoomMenu.mjs";
import { DefaultZoomMenuContent } from "./lib/ui/components/ZoomMenu/DefaultZoomMenuContent.mjs";
import { PORTRAIT_BREAKPOINT } from "./lib/ui/constants.mjs";
import {
  TldrawUiA11yProvider,
  useA11y
} from "./lib/ui/context/a11y.mjs";
import {
  unwrapLabel,
  useActions
} from "./lib/ui/context/actions.mjs";
import {
  AssetUrlsProvider,
  useAssetUrls
} from "./lib/ui/context/asset-urls.mjs";
import {
  BreakPointProvider,
  useBreakpoint
} from "./lib/ui/context/breakpoints.mjs";
import {
  TldrawUiComponentsProvider,
  useTldrawUiComponents
} from "./lib/ui/context/components.mjs";
import {
  TldrawUiDialogsProvider,
  useDialogs
} from "./lib/ui/context/dialogs.mjs";
import {
  TldrawUiEventsProvider,
  useUiEvents
} from "./lib/ui/context/events.mjs";
import {
  TldrawUiContextProvider
} from "./lib/ui/context/TldrawUiContextProvider.mjs";
import {
  TldrawUiToastsProvider,
  useToasts
} from "./lib/ui/context/toasts.mjs";
import {
  useCanApplySelectionAction,
  useCanRedo,
  useCanUndo,
  useUnlockedSelectedShapesCount
} from "./lib/ui/hooks/menu-hooks.mjs";
import {
  handleNativeOrMenuCopy,
  useMenuClipboardEvents,
  useNativeClipboardEvents
} from "./lib/ui/hooks/useClipboardEvents.mjs";
import {
  useCollaborationStatus,
  useShowCollaborationUi
} from "./lib/ui/hooks/useCollaborationStatus.mjs";
import { useCopyAs } from "./lib/ui/hooks/useCopyAs.mjs";
import { useExportAs } from "./lib/ui/hooks/useExportAs.mjs";
import { useKeyboardShortcuts } from "./lib/ui/hooks/useKeyboardShortcuts.mjs";
import { useLocalStorageState } from "./lib/ui/hooks/useLocalStorageState.mjs";
import { useMenuIsOpen } from "./lib/ui/hooks/useMenuIsOpen.mjs";
import { useReadonly } from "./lib/ui/hooks/useReadonly.mjs";
import { useRelevantStyles } from "./lib/ui/hooks/useRelevantStyles.mjs";
import {
  onDragFromToolbarToCreateShape,
  useTools
} from "./lib/ui/hooks/useTools.mjs";
import { RTL_LANGUAGES } from "./lib/ui/hooks/useTranslation/translations.mjs";
import {
  useCurrentTranslation,
  useDirection,
  useTranslation
} from "./lib/ui/hooks/useTranslation/useTranslation.mjs";
import { iconTypes } from "./lib/ui/icon-types.mjs";
import { useDefaultHelpers } from "./lib/ui/overrides.mjs";
import { TldrawUi, TldrawUiInFrontOfTheCanvas } from "./lib/ui/TldrawUi.mjs";
import { containBoxSize, downsizeImage } from "./lib/utils/assets/assets.mjs";
import { preloadFont } from "./lib/utils/assets/preload-font.mjs";
import { getEmbedInfo } from "./lib/utils/embeds/embeds.mjs";
import { putExcalidrawContent } from "./lib/utils/excalidraw/putExcalidrawContent.mjs";
import { copyAs } from "./lib/utils/export/copyAs.mjs";
import { downloadFile, exportAs } from "./lib/utils/export/exportAs.mjs";
import { fitFrameToContent, removeFrame } from "./lib/utils/frames/frames.mjs";
import {
  defaultEditorAssetUrls,
  setDefaultEditorAssetUrls
} from "./lib/utils/static-assets/assetUrls.mjs";
import { sanitizeSvg } from "./lib/utils/svg/sanitizeSvg.mjs";
import {
  defaultAddFontsFromNode,
  KeyboardShiftEnterTweakExtension,
  renderHtmlFromRichText,
  renderHtmlFromRichTextForMeasurement,
  renderPlaintextFromRichText,
  renderRichTextFromHTML,
  tipTapDefaultExtensions
} from "./lib/utils/text/richText.mjs";
import { truncateStringWithEllipsis } from "./lib/utils/text/text.mjs";
import {
  buildFromV1Document,
  TLV1AlignStyle,
  TLV1AssetType,
  TLV1ColorStyle,
  TLV1DashStyle,
  TLV1Decoration,
  TLV1FontStyle,
  TLV1ShapeType,
  TLV1SizeStyle
} from "./lib/utils/tldr/buildFromV1Document.mjs";
import {
  parseAndLoadDocument,
  parseTldrawJsonFile,
  serializeTldrawJson,
  serializeTldrawJsonBlob,
  TLDRAW_FILE_EXTENSION
} from "./lib/utils/tldr/file.mjs";
registerTldrawLibraryVersion(
  "tldraw",
  "5.1.1",
  "esm"
);
export {
  ASPECT_RATIO_OPTIONS,
  ASPECT_RATIO_TO_VALUE,
  AccessibilityMenu,
  AlignMenuItems,
  ArrangeMenuSubmenu,
  ArrowBindingHintOverlayUtil,
  ArrowBindingUtil,
  ArrowDownToolbarItem,
  ArrowHintOverlayUtil,
  ArrowLeftToolbarItem,
  ArrowRightToolbarItem,
  ArrowShapeTool,
  ArrowShapeUtil,
  ArrowToolbarItem,
  ArrowUpToolbarItem,
  AssetToolbarItem,
  AssetUrlsProvider,
  BookmarkAssetUtil,
  BookmarkShapeUtil,
  BreakPointProvider,
  BrushOverlayUtil,
  CenteredTopPanelContainer,
  CheckBoxToolbarItem,
  ClipboardMenuGroup,
  CloudToolbarItem,
  CollaboratorBrushOverlayUtil,
  CollaboratorCursorOverlayUtil,
  CollaboratorHintOverlayUtil,
  CollaboratorScribbleOverlayUtil,
  CollaboratorShapeIndicatorOverlayUtil,
  ColorSchemeMenu,
  DefaultContextMenu as ContextMenu,
  ConversionsMenuGroup,
  ConvertToBookmarkMenuItem,
  ConvertToEmbedMenuItem,
  CopyAsMenuGroup,
  CopyMenuItem,
  CursorChatItem,
  CutMenuItem,
  DEFAULT_EMBED_DEFINITIONS,
  DEFAULT_MAX_ASSET_SIZE,
  DEFAULT_MAX_IMAGE_DIMENSION,
  DebugFlags,
  DefaultA11yAnnouncer,
  DefaultActionsMenu,
  DefaultActionsMenuContent,
  DefaultContextMenu2 as DefaultContextMenu,
  DefaultContextMenuContent,
  DefaultDebugMenu,
  DefaultDebugMenuContent,
  DefaultDialogs,
  DefaultFollowingIndicator,
  DefaultFontFaces,
  DefaultHelpMenu,
  DefaultHelpMenuContent,
  DefaultHelperButtons,
  DefaultHelperButtonsContent,
  DefaultImageToolbar,
  DefaultImageToolbarContent,
  DefaultKeyboardShortcutsDialog,
  DefaultKeyboardShortcutsDialogContent,
  DefaultMainMenu,
  DefaultMainMenuContent,
  DefaultMenuPanel,
  DefaultMinimap,
  DefaultNavigationPanel,
  DefaultPageMenu,
  DefaultPeopleMenu,
  DefaultPeopleMenuAvatar,
  DefaultPeopleMenuContent,
  DefaultPeopleMenuFacePile,
  DefaultPeopleMenuItem,
  DefaultQuickActions,
  DefaultQuickActionsContent,
  DefaultRichTextToolbar,
  DefaultRichTextToolbarContent,
  DefaultSharePanel,
  DefaultStylePanel,
  DefaultStylePanelContent,
  DefaultToasts,
  DefaultToolbar,
  DefaultToolbarContent,
  DefaultUserPresenceEditor,
  DefaultVideoToolbar,
  DefaultVideoToolbarContent,
  DefaultZoomMenu,
  DefaultZoomMenuContent,
  DeleteMenuItem,
  DiamondToolbarItem,
  DistributeMenuItems,
  DrawShapeTool,
  DrawShapeUtil,
  DrawToolbarItem,
  DuplicateMenuItem,
  EditLinkMenuItem,
  EditMenuSubmenu,
  EditSubmenu,
  EllipseToolbarItem,
  EmbedShapeUtil,
  EraserTool,
  EraserToolbarItem,
  ExampleDialog,
  ExportFileContentSubMenu,
  ExtrasGroup,
  FeatureFlags,
  FitFrameToContentMenuItem,
  FrameShapeTool,
  FrameShapeUtil,
  FrameToolbarItem,
  GeoShapeTool,
  GeoShapeUtil,
  GroupMenuItem,
  GroupOrUngroupMenuItem,
  HandTool,
  HandToolbarItem,
  HeartToolbarItem,
  HexagonToolbarItem,
  HighlightShapeTool,
  HighlightShapeUtil,
  HighlightToolbarItem,
  ImageAssetUtil,
  ImageShapeUtil,
  InputModeMenu,
  KeyboardShiftEnterTweakExtension,
  KeyboardShortcutsMenuItem,
  LanguageMenu,
  LaserTool,
  LaserToolbarItem,
  LineShapeTool,
  LineShapeUtil,
  LineToolbarItem,
  LockGroup,
  MiscMenuGroup,
  MobileStylePanel,
  MoveToPageMenu,
  NoteShapeTool,
  NoteShapeUtil,
  NoteToolbarItem,
  OfflineIndicator,
  OvalToolbarItem,
  OverflowingToolbar,
  PORTRAIT_BREAKPOINT,
  PageItemInput,
  PageItemSubmenu,
  PasteMenuItem,
  PathBuilder,
  PathBuilderGeometry2d,
  DefaultPeopleMenu2 as PeopleMenu,
  PlainTextArea,
  PlainTextLabel,
  PreferencesGroup,
  PrintItem,
  RTL_LANGUAGES,
  RectangleToolbarItem,
  RemoveFrameMenuItem,
  ReorderMenuItems,
  ReorderMenuSubmenu,
  RhombusToolbarItem,
  RichTextArea,
  RichTextLabel,
  RichTextSVG,
  RotateCWMenuItem,
  ScribbleOverlayUtil,
  SelectAllMenuItem,
  SelectTool,
  SelectToolbarItem,
  SelectionForegroundOverlayUtil,
  ShapeHandleOverlayUtil,
  SnapIndicatorOverlayUtil,
  Spinner,
  StackMenuItems,
  StarToolbarItem,
  StylePanelArrowKindPicker,
  StylePanelArrowheadPicker,
  StylePanelButtonPicker,
  StylePanelButtonPickerInline,
  StylePanelColorPicker,
  StylePanelContextProvider,
  StylePanelDashPicker,
  StylePanelDoubleDropdownPicker,
  StylePanelDoubleDropdownPickerInline,
  StylePanelDropdownPicker,
  StylePanelDropdownPickerInline,
  StylePanelFillPicker,
  StylePanelFontPicker,
  StylePanelGeoShapePicker,
  StylePanelLabelAlignPicker,
  StylePanelOpacityPicker,
  StylePanelSection,
  StylePanelSizePicker,
  StylePanelSplinePicker,
  StylePanelSubheading,
  StylePanelTextAlignPicker,
  TLDRAW_FILE_EXTENSION,
  TLV1AlignStyle,
  TLV1AssetType,
  TLV1ColorStyle,
  TLV1DashStyle,
  TLV1Decoration,
  TLV1FontStyle,
  TLV1ShapeType,
  TLV1SizeStyle,
  TextShapeTool,
  TextShapeUtil,
  TextToolbarItem,
  Tldraw,
  TldrawImage,
  TldrawUi,
  TldrawUiA11yProvider,
  TldrawUiButton,
  TldrawUiButtonCheck,
  TldrawUiButtonIcon,
  TldrawUiButtonLabel,
  TldrawUiColumn,
  TldrawUiComponentsProvider,
  TldrawUiContextProvider,
  TldrawUiContextualToolbar,
  TldrawUiDialogBody,
  TldrawUiDialogCloseButton,
  TldrawUiDialogFooter,
  TldrawUiDialogHeader,
  TldrawUiDialogTitle,
  TldrawUiDialogsProvider,
  TldrawUiDropdownMenuCheckboxItem,
  TldrawUiDropdownMenuContent,
  TldrawUiDropdownMenuGroup,
  TldrawUiDropdownMenuIndicator,
  TldrawUiDropdownMenuItem,
  TldrawUiDropdownMenuRoot,
  TldrawUiDropdownMenuSub,
  TldrawUiDropdownMenuSubContent,
  TldrawUiDropdownMenuSubTrigger,
  TldrawUiDropdownMenuTrigger,
  TldrawUiEventsProvider,
  TldrawUiGrid,
  TldrawUiIcon,
  TldrawUiInFrontOfTheCanvas,
  TldrawUiInput,
  TldrawUiKbd,
  TldrawUiMenuActionCheckboxItem,
  TldrawUiMenuActionItem,
  TldrawUiMenuCheckboxItem,
  TldrawUiMenuContextProvider,
  TldrawUiMenuGroup,
  TldrawUiMenuItem,
  TldrawUiMenuSubmenu,
  TldrawUiMenuToolItem,
  TldrawUiOrientationProvider,
  TldrawUiPopover,
  TldrawUiPopoverContent,
  TldrawUiPopoverTrigger,
  TldrawUiRow,
  TldrawUiSelect,
  TldrawUiSelectContent,
  TldrawUiSelectItem,
  TldrawUiSelectTrigger,
  TldrawUiSelectValue,
  TldrawUiSlider,
  TldrawUiToastsProvider,
  TldrawUiToolbar,
  TldrawUiToolbarButton,
  TldrawUiToolbarToggleGroup,
  TldrawUiToolbarToggleItem,
  TldrawUiTooltip,
  TldrawUiTooltipProvider,
  TldrawUiTranslationProvider,
  ToggleAutoSizeMenuItem,
  ToggleDebugModeItem,
  ToggleDynamicSizeModeItem,
  ToggleEdgeScrollingItem,
  ToggleEnhancedA11yModeItem,
  ToggleFocusModeItem,
  ToggleGridItem,
  ToggleInvertZoomItem,
  ToggleKeyboardShortcutsItem,
  ToggleLockMenuItem,
  TogglePasteAtCursorItem,
  ToggleReduceMotionItem,
  ToggleSnapModeItem,
  ToggleToolLockItem,
  ToggleToolLockedButton,
  ToggleTransparentBgMenuItem,
  ToggleWrapModeItem,
  ToolbarItem,
  TrapezoidToolbarItem,
  TriangleToolbarItem,
  UndoRedoGroup,
  UngroupMenuItem,
  UnlockAllMenuItem,
  VideoAssetUtil,
  VideoShapeUtil,
  ViewSubmenu,
  XBoxToolbarItem,
  ZoomBrushOverlayUtil,
  ZoomOrRotateMenuItem,
  ZoomTo100MenuItem,
  ZoomToFitMenuItem,
  ZoomToSelectionMenuItem,
  ZoomTool,
  allDefaultFontFaces,
  buildFromV1Document,
  centerSelectionAroundPoint,
  clearArrowTargetState,
  containBoxSize,
  copyAs,
  createBookmarkFromUrl,
  createEmptyBookmarkShape,
  createShapesForAssets,
  defaultAddFontsFromNode,
  defaultAssetUtils,
  defaultBindingUtils,
  defaultEditorAssetUrls,
  defaultGeoTypeDefinitions,
  defaultHandleExternalEmbedContent,
  defaultHandleExternalExcalidrawContent,
  defaultHandleExternalFileAsset,
  defaultHandleExternalFileContent,
  defaultHandleExternalFileReplaceContent,
  defaultHandleExternalSvgTextContent,
  defaultHandleExternalTextContent,
  defaultHandleExternalTldrawContent,
  defaultHandleExternalUrlAsset,
  defaultHandleExternalUrlContent,
  defaultOverlayUtils,
  defaultShapeTools,
  defaultShapeUtils,
  defaultTools,
  downloadFile,
  downsizeImage,
  embedShapePermissionDefaults,
  exportAs,
  fitFrameToContent,
  getArrowBindings,
  getArrowInfo,
  getArrowTargetState,
  getArrowTerminalsInArrowSpace,
  getAssetInfo,
  getColorStyleItems,
  getCropBox,
  getDefaultCrop,
  getDisplayValues,
  getEmbedInfo,
  getFontFamily,
  getFontStyleItems,
  getGeoTypeDefinition,
  getHitShapeOnCanvasPointerDown,
  getPointsFromDrawSegment,
  getPointsFromDrawSegments,
  getStroke,
  getStrokeOutlinePoints,
  getStrokePoints,
  getSvgPathFromStrokePoints,
  getUncroppedSize,
  handleNativeOrMenuCopy,
  hideAllTooltips,
  iconTypes,
  notifyIfFileNotAllowed,
  onDragFromToolbarToCreateShape,
  parseAndLoadDocument,
  parseTldrawJsonFile,
  preloadFont,
  putExcalidrawContent,
  registerDefaultExternalContentHandlers,
  registerDefaultSideEffects,
  removeFrame,
  renderHtmlFromRichText,
  renderHtmlFromRichTextForMeasurement,
  renderPlaintextFromRichText,
  renderRichTextFromHTML,
  sanitizeSvg,
  serializeTldrawJson,
  serializeTldrawJsonBlob,
  setDefaultEditorAssetUrls,
  setDefaultUiAssetUrls,
  setStrokePointRadii,
  startEditingShapeWithRichText,
  tipTapDefaultExtensions,
  truncateStringWithEllipsis,
  unknownEmbedShapePermissionOverrides,
  unwrapLabel,
  updateArrowTargetState,
  useA11y,
  useActions,
  useAssetUrls,
  useBreakpoint,
  useCanApplySelectionAction,
  useCanRedo,
  useCanUndo,
  useCollaborationStatus,
  useCopyAs,
  useCurrentTranslation,
  useDefaultHelpers,
  useDialogs,
  useDirection,
  useEditablePlainText,
  useEditableRichText,
  useExportAs,
  useImageOrVideoAsset,
  useIsToolSelected,
  useKeyboardShortcuts,
  useLocalStorageState,
  useMenuClipboardEvents,
  useMenuIsOpen,
  useNativeClipboardEvents,
  usePrefersReducedMotion,
  useReadonly,
  useRelevantStyles,
  useSelectedShapesAnnouncer,
  useShowCollaborationUi,
  useStylePanelContext,
  useTldrawUiComponents,
  useTldrawUiOrientation,
  useToasts,
  useTools,
  useTranslation,
  useUiEvents,
  useUnlockedSelectedShapesCount
};
//# sourceMappingURL=index.mjs.map
